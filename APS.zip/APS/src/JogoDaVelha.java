import java.util.Scanner;

public class JogoDaVelha
{
    private int cont;
    private char posicao[] = new char[10];
    private char jogador;

    public static void main(String args[])
    {
        String continuar;
        JogoDaVelha velha = new JogoDaVelha();
        do{
            velha.jogoNovo();
            velha.jogar();
            System.out.println ("Jogar de novo? (digite 'sim') ");
            Scanner in =new Scanner(System.in);
            continuar=in.nextLine();
        }while (continuar.equals("sim"));
    }

    public  void jogoNovo()
    {
        char posicoesDefinidas[] = {'0','1', '2', '3', '4', '5', '6', '7', '8', '9'};
        int i;
        cont = 0;
        jogador = 'X';
        for (i=1; i<10; i++) posicao[i]=posicoesDefinidas[i];
        jogoAtual();
    }

    public  String jogoAtual()
    {
        System.out.println( "\n\n" );
        System.out.println(  "\n\n" );
        System.out.println(  "\n\n\t\t" + posicao [1] + "   | " +posicao [2]+ "  | " +posicao [3]);
        System.out.println(  " \t\t    |    |   " );
        System.out.println(  " \t\t____|____|____ " );
        System.out.println(  "\n\n\t\t" +posicao [4]+ "   | " +posicao [5]+ "  | " +posicao [6]);
        System.out.println(  " \t\t    |    |   " );
        System.out.println(  " \t\t____|____|____ " );
        System.out.println(  "\n\n\t\t" +posicao [7]+ "   | " +posicao [8]+ "  | " +posicao [9]);
        System.out.println(  " \t\t    |    |   " );
        System.out.println(  " \t\t____|____|____ " );
        System.out.println(  "\n\n" );
        return "currentBoard";
    }

    public  void jogar()
    {
        int local;
        char vazio = ' ';

        System.out.println(  "Jogador " + getJogador() +" jogue primeiro com a letra 'X'" );

        do {
            jogoAtual();

            System.out.println( "\n\n Jogador " + getJogador() +" escolha a posicao" );

            boolean posicaoTomada = true;
            while (posicaoTomada) {
                Scanner in =new Scanner (System.in);
                local=in.nextInt();
                posicaoTomada = checaPosicao(local);
                if(posicaoTomada==false)
                posicao[local]=getJogador();
            }

            System.out.println(  "Bom movimento" );

            jogoAtual();

            proximoJogador();
        }while (checaVencedor() == vazio);

    }

    public  char checaVencedor()
    {
        char Vencedor = ' ';

        if (posicao[1] == 'X' && posicao[2] == 'X' && posicao[3] == 'X') Vencedor = 'X';
        if (posicao[4] == 'X' && posicao[5] == 'X' && posicao[6] == 'X') Vencedor = 'X';
        if (posicao[7] == 'X' && posicao[8] == 'X' && posicao[9] == 'X') Vencedor = 'X';
        if (posicao[1] == 'X' && posicao[4] == 'X' && posicao[7] == 'X') Vencedor = 'X';
        if (posicao[2] == 'X' && posicao[5] == 'X' && posicao[8] == 'X') Vencedor = 'X';
        if (posicao[3] == 'X' && posicao[6] == 'X' && posicao[9] == 'X') Vencedor = 'X';
        if (posicao[1] == 'X' && posicao[5] == 'X' && posicao[9] == 'X') Vencedor = 'X';
        if (posicao[3] == 'X' && posicao[5] == 'X' && posicao[7] == 'X') Vencedor = 'X';
        if (Vencedor == 'X' )
        {System.out.println("Jogador X ganhou" );
            return Vencedor;
        }

        if (posicao[1] == 'O' && posicao[2] == 'O' && posicao[3] == 'O') Vencedor = 'O';
        if (posicao[4] == 'O' && posicao[5] == 'O' && posicao[6] == 'O') Vencedor = 'O';
        if (posicao[7] == 'O' && posicao[8] == 'O' && posicao[9] == 'O') Vencedor = 'O';
        if (posicao[1] == 'O' && posicao[4] == 'O' && posicao[7] == 'O') Vencedor = 'O';
        if (posicao[2] == 'O' && posicao[5] == 'O' && posicao[8] == 'O') Vencedor = 'O';
        if (posicao[3] == 'O' && posicao[6] == 'O' && posicao[9] == 'O') Vencedor = 'O';
        if (posicao[1] == 'O' && posicao[5] == 'O' && posicao[9] == 'O') Vencedor = 'O';
        if (posicao[3] == 'O' && posicao[5] == 'O' && posicao[7] == 'O') Vencedor = 'O';
        if (Vencedor == 'O' )
        {
            System.out.println( "Jogador O ganhou" );
        return Vencedor; }

        for(int i=1;i<10;i++)
        {
            if(posicao[i]=='X' || posicao[i]=='O')
            {
                if(i==9)
                {
                    char Empate='E';
                    System.out.println(" VELHA ");
                    return Empate;
                }
                continue;
            }
            else
            break;
        }
        return Vencedor;
    }

    public  boolean checaPosicao(int local)
    {
        if (posicao[local] == 'X' || posicao[local] == 'O')
        {
            System.out.println("Escolha uma posicao valida");
            return true;
        }
        else {
            return false;
        }
    }

    public  void proximoJogador()
    {
        if (jogador == 'X')
        jogador = 'O';
        else jogador = 'X';
    }

    public String getTitulo()
    {
        return "Jogo da Velha" ;
    }

    public  char getJogador()
    {
        return jogador;
    }

}